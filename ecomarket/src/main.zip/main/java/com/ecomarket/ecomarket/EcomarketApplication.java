package com.ecomarket.ecomarket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcomarketApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcomarketApplication.class, args);
	}

}
